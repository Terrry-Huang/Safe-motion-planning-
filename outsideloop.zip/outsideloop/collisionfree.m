%% �⻷ nc<np
clc;
clear;
close all;

%% ��������
%λ�û�
T = 5;     Ts = 0.125;   simulink_time = 2 * T;     n_xi = T / Ts;  N = simulink_time / Ts;   nc = 5;
g = 9.81;   G = [0; 0; g];     
xi = [2; 1; 2; 0; 0; 0];    uxi = [0; 0; 0];
A = [0 0 0 1 0 0;   0 0 0 0 1 0;    0 0 0 0 0 1;    0 0 0 0 0 0;    0 0 0 0 0 0;    0 0 0 0 0 0];
B = [0 0 0; 0 0 0;  0 0 0;  1 0 0;  0 1 0;  0 0 1];
%���ݴ洢
out_xi = [];    out_uxi = [];   ref1 = [];  xio = [];   uxio = [];  
out_xi = [out_xi xi];   out_uxi = [out_uxi uxi];
%Լ������
max_uxi = 20; 
max_xif = [3; 1.5; 4; 4; 4; 4];    min_xif = [-3; -1.5; 0.2; -4; -4; -4];
max_xi = [3.5; 1.7; 4.5; 4.2; 4.2; 4.2];    min_xi = [-3.5; -1.7; 0; -4.2; -4.2; -4.2];
%����
Q_eta = eye(6);     
R_eta = 0.01 * eye(3);
S_eta = [3 0 0 0 0 0;   0 3 0 0 0 0;    0 0 1 0 0 0;    0 0 0 0 0 0;    0 0 0 0 0 0;    0 0 0 0 0 0] * 10000;
S_xi = 10000 * eye(3); %reference��10000
Q_xi = eye(6);
R_xi = 0.1 * eye(3);
%��̬�ϰ��ﶥ������
[Vr,Vs,x_obs] = get_V(Ts, simulink_time, 0, 0);
d1 = 0.45;   d2 = 0.5;

%% �ο��켣
for t = 0 : Ts : (simulink_time + T)
    ref1 = [ref1; 2 * cos(0.4 * pi * t), 2 * sin(0.4 * pi * t), 3];
end
figure(1)
plot3(ref1(:,1), ref1(:,2), ref1(:,3), 'r', 'LineWidth', 1)
hold on

%% ���ſɴ�켣
% constraints = [];
% objective = 0;
% U_xio = sdpvar(repmat(3, 1, N),ones(1, N) );               
% Xi_o = sdpvar(repmat(6, 1, N + 1),ones(1, N + 1));
% n = sdpvar(N, 3);
% 
% for i = 1 : N
%     constraints = [constraints; Xi_o{i + 1} == Xi_o{i} + Ts * A * Xi_o{i} + Ts * B * U_xio{i}];
%     constraints = [constraints; Xi_o{i + 1} <= max_xif];
%     constraints = [constraints; n(i,1)^2 + n(i,2)^2 + n(i,3)^2 == 1];
%     constraints = [constraints; n(i,:) * Xi_o{i + 1}(1 : 3) * ones(1,4) - n(i,:) * Vs(:,4 * i - 3 : 4 * i) >= d2 * ones(1,4)];
%     constraints = [constraints; min_xif <= Xi_o{i + 1}];
%     constraints = [constraints; norm(U_xio{i} + G) <= max_uxi];
%     objective = objective + (Xi_o{i}(1 : 3) - ref1(i, :)')' * S_xi * (Xi_o{i}(1 : 3) - ref1(i, :)');
% end
% constraints = [constraints; Xi_o{N + 1} == Xi_o{1}];
% opt = sdpsettings('verbose',0,'solver','ipopt');
% opt.ipopt.max_iter = 6000;
% result = optimize(constraints ,objective, opt);
% if result.problem == 0
%     disp('optimal reachable trajectory: successful');
% else
%     disp('optimal reachable trajectory: failed');
% end
% 
% % ��¼���ſɸ��켣
% for i = 1 : N
%     xio = [xio value(Xi_o{i})];
%     uxio = [uxio value(U_xio{i})];
% end
% xio = [xio value(Xi_o{N + 1})];
% plot3(xio(1, :), xio(2, :), xio(3, :), 'b', 'LineWidth', 1)
% axis([-3 3 -3 3 0 4])
% hold on


%% �����й켣
tic
for k = 1 : N
    disp(num2str(k));
    constraints = [];
    objective = 0;
    Uxi = sdpvar(repmat(3, 1, nc),ones(1, nc) );               
    Xi = sdpvar(repmat(6, 1, nc + 1),ones(1, nc + 1));
    Uxir = sdpvar(repmat(3, 1, n_xi),ones(1, n_xi) );               
    Xir = sdpvar(repmat(6, 1, n_xi + 1),ones(1, n_xi + 1));
    %�Ƿ���Ҫ��̬����
    if k <= 24
        n = sdpvar(nc, 3);
        nr = sdpvar(n_xi, 3);
        for i = 1 : nc
            constraints = [constraints; n(i,1)^2 + n(i,2)^2 + n(i,3)^2 == 1];
            constraints = [constraints; n(i,:) * Xi{i + 1}(1 : 3) * ones(1,4) - n(i,:) * Vr(:,4 * (i + k - 1) - 3 : 4 * (i + k - 1)) >= d1 * ones(1,4)];
        end
        for i = 1 : n_xi
            constraints = [constraints; nr(i,1)^2 + nr(i,2)^2 + nr(i,3)^2 == 1];
            constraints = [constraints; nr(i,:) * Xir{i + 1}(1 : 3) * ones(1,4) - nr(i,:) * Vs(:,4 * (i + k - 1) - 3 : 4 * (i + k - 1)) >= d2 * ones(1,4)];
        end
    end
    constraints = [constraints; Xi{1} == xi];
    for i = 1 : nc
        constraints = [constraints; Xi{i + 1} == Xi{i} + Ts * A * Xi{i} + Ts * B * Uxi{i}];
        constraints = [constraints; Xi{i + 1} <= max_xi];
        constraints = [constraints; min_xi <= Xi{i + 1}];
        constraints = [constraints; norm(Uxi{i} + G) <= max_uxi];
        objective = objective + (Xi{i} - Xir{i})' * Q_xi * (Xi{i} - Xir{i}) + (Uxi{i} - Uxir{i})' * R_xi * (Uxi{i} - Uxir{i});
    end
    
    for i = 1 : n_xi
        constraints = [constraints; Xir{i + 1} == Xir{i} + Ts * A * Xir{i} + Ts * B * Uxir{i}];
        constraints = [constraints; Xir{i + 1} <= max_xif];
        constraints = [constraints; min_xif <= Xir{i + 1}];
        constraints = [constraints; norm(Uxir{i} + G) <= max_uxi];
        objective = objective + (Xir{i}(1 : 3) - ref1(i + k - 1, :)')' * S_xi * (Xir{i}(1 : 3) - ref1(i + k - 1, :)');
    end
    constraints = [constraints; Xi{nc + 1} == Xir{nc + 1}];
    constraints = [constraints; Xir{n_xi + 1}== Xir{1}];
    opt = sdpsettings('verbose',0,'solver','ipopt');
    opt.ipopt.max_iter = 6000;
    result = optimize(constraints ,objective, opt);
    if result.problem == 0
        disp('position system: successful');
    else
        disp('position system: failed');
    end
    
    out_xi = [out_xi value(Xi{2})];   
    out_uxi = [out_uxi value(Uxi{1})];
    xi = value(Xi{2});
    
end
toc

plot3(out_xi(1, :), out_xi(2, :), out_xi(3, :), 'g', 'LineWidth', 1) 
axis([-3 3 -3 3 0 4])
hold on
