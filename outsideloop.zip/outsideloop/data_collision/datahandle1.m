clc;
clear;
close all;
load data1.mat


%% 三维曲线?
figure(1)
plot3(ref1(:,1), ref1(:,2), ref1(:,3), 'r', 'LineWidth', 2)
hold on
plot3(xio(1, :), xio(2, :), xio(3, :), 'b', 'LineWidth', 2)
hold on
plot3(out_xi(1, :), out_xi(2, :), out_xi(3, :), 'g', 'LineWidth', 2)
axis([min_xi(1)-0.5 max_xi(1)+0.5 min_xi(2)-0.5 max_xi(2)+0.5 min_xi(3)-0.5 max_xi(3)+0.5])
hold on

data = [];


%% 坐标轴分量
figure(2)
subplot(3,1,1)
plot([0 simulink_time],[max_xi(1),max_xi(1)],'r--',[0 simulink_time],[min_xi(1),min_xi(1)],'r--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], ref1(1:N+1,1),'b',[0:Ts:simulink_time], out_xi(1,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(1)-0.5 max_xi(1)+0.5])
xlabel('$time/s$','interpreter','latex', 'FontSize', 8);
ylabel('$x/m$','interpreter','latex', 'FontSize', 8);
grid on
subplot(3,1,2)
plot([0 simulink_time],[max_xi(2),max_xi(2)],'r--',[0 simulink_time],[min_xi(2),min_xi(2)],'r--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], ref1(1:N+1,2),'b',[0:Ts:simulink_time], out_xi(2,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(2)-0.5 max_xi(2)+0.5])
xlabel('$time/s$','interpreter','latex', 'FontSize', 8);
ylabel('$y/m$','interpreter','latex', 'FontSize', 8);
grid on
subplot(3,1,3)

plot([0 simulink_time],[max_xi(3),max_xi(3)],'r--',[0 simulink_time],[min_xi(3),min_xi(3)],'r--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], ref1(1:N+1,3),'b',[0:Ts:simulink_time], out_xi(3,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(3)-0.5 max_xi(3)+0.5])
xlabel('$time/s$','interpreter','latex', 'FontSize', 8);
ylabel('$z/m$','interpreter','latex', 'FontSize', 8);
grid on

%% 速度
figure(3)
subplot(3,1,1)
plot([0 simulink_time],[max_xi(4),max_xi(4)],'b--',[0 simulink_time],[min_xi(4),min_xi(4)],'b--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], out_xi(4,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(4)-0.5 max_xi(4)+0.5])
hold on
subplot(3,1,2)
plot([0 simulink_time],[max_xi(5),max_xi(5)],'b--',[0 simulink_time],[min_xi(5),min_xi(5)],'b--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], out_xi(5,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(5)-0.5 max_xi(5)+0.5])
hold on
subplot(3,1,3)
plot([0 simulink_time],[max_xi(6),max_xi(6)],'b--',[0 simulink_time],[min_xi(6),min_xi(6)],'b--','LineWidth',2)
hold on 
plot([0:Ts:simulink_time], out_xi(6,:),'g','LineWidth',2)
hold on
axis([0 simulink_time min_xi(6)-0.5 max_xi(6)+0.5])
grid on

%% 控制约束
u = [];
for i = 1 : simulink_time / Ts + 1
    u = [u; norm(out_uxi(1 : 3, i) + [0; 0; 9.81])];
end
figure(4)
plot([0 simulink_time],[max_uxi,max_uxi],'r--','LineWidth',2)
hold on
plot([0:Ts:simulink_time], u, 'b','LineWidth',2)
hold on
axis([0 simulink_time 0 max_uxi+0.5])
xlabel('$time/s$','interpreter','latex', 'FontSize', 8);
ylabel('$\left\|u+[0,0,g]^{T}\right\|$','interpreter','latex', 'FontSize', 8);
handle = legend('$\bar{u}$','$\left\|u+[0,0,g]^{T}\right\|$');
set(handle,'Interpreter','latex', 'FontSize',8)
grid on



%% 动态图
P = [0 0.4 0 -4.5; 0 0 0.8 -2; 0.01 0 0 2.8437];
figure(7)
plot3(ref1(:,1),ref1(:,2),ref1(:,3),'b','LineWidth',2);
hold on
MakeGif('collision-free1.gif',1);
hold on
for t = 0 : Ts : simulink_time
    T = [t^3 t^2 t 1];
    x = T * P';
    i = round(t/Ts) + 1;
    axis([-3 3 -3 3 0 4])
    plot3(x(1),x(2),x(3),'.r')
    hold on
    plot3(out_xi(1,i),out_xi(2,i),out_xi(3,i),'*c')
    MakeGif('collision-free1.gif',i);
    hold on
end
X=[];V = [];
for t = 0 : Ts : simulink_time
    T = [t^3 t^2 t 1];
    TT = [3 * t^2  2*t  1  0];
    v = TT*P';
    x = T * P';
    X = [X; x];
    V = [V;v];
end

