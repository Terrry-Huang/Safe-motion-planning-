%% �⻷
clc;
clear;
close all;
%% ��������
Ts = 0.25;
T = 5;
N = T / Ts;
simulink_time = 2 * T;
nc = 5;
g = 9.81;
G = [0; 0; g];
ref =[];
A = [0 0 0 1 0 0;
     0 0 0 0 1 0;
     0 0 0 0 0 1;
     0 0 0 0 0 0;
     0 0 0 0 0 0;
     0 0 0 0 0 0];
B = [0 0 0;
     0 0 0;
     0 0 0;
     1 0 0;
     0 1 0;
     0 0 1];
S = 10000 * eye(3);
Q = eye(6);
R = 0.1 * eye(3);
maxx = [3; 1.5; 4; 4; 4; 4];
minx = [-3; -1.5; 0; -4; -4; -4];
x0 = [2; 1; 2; 0; 0; 0];    %��ʼλ��
x = []; u = []; xo = []; uo = [];   
x = [x x0];
%% �ο��켣
for t = 0 : Ts : 3 * T
    ref = [ref; 2 * cos(0.4 * pi * t), 2 * sin(0.4 * pi * t), 3];
end
figure(1)
plot3(ref(:,1), ref(:,2), ref(:,3), 'r', 'LineWidth', 1)
hold on

%% ������ſɸ��켣
constraints = [];
objective = 0;
U = sdpvar(repmat(3, 1, N),ones(1, N) );               
X = sdpvar(repmat(6, 1, N + 1),ones(1, N + 1));
for i = 1 : N
    constraints = [constraints; X{i + 1} == X{i} + Ts * A * X{i} + Ts * B * U{i}];
    constraints = [constraints; X{i + 1} <= maxx];
    constraints = [constraints; minx <= X{i + 1}];
    %constraints = [constraints; U{i}(1).* U{i}(1) + U{i}(2).* U{i}(2) + (U{i}(3) + g).* (U{i}(3) + g) <= 225 ];
    constraints = [constraints; norm(U{i} + G) <= 15];
    objective = objective + (X{i}(1 : 3) - ref(i, :)')' * S * (X{i}(1 : 3) - ref(i, :)');
end
constraints = [constraints; X{N + 1} == X{1}];
opt = sdpsettings('verbose',0,'solver','ipopt');
opt.ipopt.max_iter = 6000;
result = optimize(constraints ,objective, opt);
if result.problem == 0
    disp('���ɹ�');
else
    disp('������');
end
% ��¼���ſɸ��켣
for i = 1 : N
    xo = [xo value(X{i})];
    uo = [uo value(U{i})];
end
xo = [xo value(X{N + 1})];
plot3(xo(1, :), xo(2, :), xo(3, :), 'b', 'LineWidth', 1)
axis([-3 3 -3 3 0 4])
hold on

%% ���ݵ�ǰλ�õĿɸ��ٹ켣
t0 = cputime;
tic
for k = 1 : simulink_time / Ts
    constraints = [];
    obj = [];
    objective = 0;
    U = sdpvar(repmat(3, 1, N),ones(1, N) );               
    X = sdpvar(repmat(6, 1, N + 1),ones(1, N + 1));
    Ur = sdpvar(repmat(3, 1, N),ones(1, N) );               
    Xr = sdpvar(repmat(6, 1, N + 1),ones(1, N + 1));
    constraints = [constraints; X{1} == x0];
    for i = 1 : nc
        constraints = [constraints; X{i + 1} == X{i} + Ts * A * X{i} + Ts * B * U{i}];
        constraints = [constraints; X{i + 1} <= maxx];
        constraints = [constraints; minx <= X{i + 1}];
        constraints = [constraints; norm(U{i} + G) <= 15];
        objective = objective + (X{i} - Xr{i})' * Q * (X{i} - Xr{i}) + (U{i} - Ur{i})' * R * (U{i} - Ur{i});
    end
    for i = 1 : N
        constraints = [constraints; Xr{i + 1} == Xr{i} + Ts * A * Xr{i} + Ts * B * Ur{i}];
        constraints = [constraints; Xr{i + 1} <= maxx];
        constraints = [constraints; minx <= Xr{i + 1}];
        constraints = [constraints; norm(Ur{i} + G) <= 15];
        objective = objective + (Xr{i}(1 : 3) - ref(i + k - 1, :)')' * S * (Xr{i}(1 : 3) - ref(i + k - 1, :)');
    end
    constraints = [constraints; X{nc + 1} == Xr{nc + 1}]; %����Լ��
    constraints = [constraints; Xr{N + 1}== Xr{1}]; %����Լ��
    ops = sdpsettings('verbose',0,'solver','ipopt');
    ops.ipopt.max_iter = 6000;
    result = optimize(constraints ,objective, ops);
    if result.problem == 0
        disp('���ɹ�');
    else
        disp('������');
    end
    x0 = value(X{2});
    u0 = value(U{1});
    x = [x x0]; u = [u u0]; obj = [obj; value(objective)];
    
    [cputime - t0, k]
end
t1 = cputime - t0;
toc
plot3(x(1, :), x(2, :), x(3, :), 'g', 'LineWidth', 1)
axis([-3 3 -3 3 0 4])
hold on

figure(2)
subplot(3 , 1 , 1)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 1),'r','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(1, :),'b','LineWidth',2)
hold on
subplot(3 , 1 , 2)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 2),'r','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(2, :),'b','LineWidth',2)
hold on
subplot(3 , 1 , 3)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 3),'r','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(3, :),'b','LineWidth',2)
hold on

figure(3)
subplot(3 , 1 , 1)
plot([0 : Ts : simulink_time], x(4, :),'b','LineWidth',2)
hold on
subplot(3 , 1 , 2)
plot([0 : Ts : simulink_time], x(5, :),'b','LineWidth',2)
hold on
subplot(3 , 1 , 3)
plot([0 : Ts : simulink_time], x(6, :),'b','LineWidth',2)
hold on

