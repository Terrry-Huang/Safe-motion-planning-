These solutions are for t \in [0,1]
