clc;
clear;
close all;

load data.mat


figure(1)
plot3(ref(:,1), ref(:,2), ref(:,3), 'r', 'LineWidth', 2)
hold on
plot3(xo(1, :), xo(2, :), xo(3, :), 'b', 'LineWidth', 2)
hold on
plot3(x(1, :), x(2, :), x(3, :), 'g', 'LineWidth', 2)
axis([-3 3 -3 3 0 4])
hold on

figure(2)
subplot(3 , 1 , 1)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 1),'r','LineWidth',2)
hold on
plot([0 simulink_time],[maxx(1) maxx(1)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(1) minx(1)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(1, :),'g','LineWidth',2)
axis([0 simulink_time minx(1) - 0.5 maxx(1) + 0.5])
hold on
subplot(3 , 1 , 2)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 2),'r','LineWidth',2)
hold on
plot([0 simulink_time],[maxx(2) maxx(2)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(2) minx(2)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(2, :),'g','LineWidth',2)
axis([0 simulink_time minx(2) - 0.5 maxx(2) + 0.5])
hold on
subplot(3 , 1 , 3)
plot([0 : Ts : simulink_time], ref(1 : simulink_time / Ts + 1, 3),'r','LineWidth',2)
hold on
plot([0 simulink_time],[maxx(3) maxx(3)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(3) minx(3)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(3, :),'g','LineWidth',2)
axis([0 simulink_time minx(3) - 0.5 maxx(3) + 0.5])
hold on

figure(3)
subplot(3 , 1 , 1)
plot([0 simulink_time],[maxx(4) maxx(4)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(4) minx(4)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(4, :),'g','LineWidth',2)
axis([0 simulink_time minx(4) - 0.5 maxx(4) + 0.5])
hold on
subplot(3 , 1 , 2)
plot([0 simulink_time],[maxx(5) maxx(5)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(5) minx(5)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(5, :),'g','LineWidth',2)
axis([0 simulink_time minx(5) - 0.5 maxx(5) + 0.5])
hold on
subplot(3 , 1 , 3)
plot([0 simulink_time],[maxx(6) maxx(6)], 'b--','LineWidth',2)
hold on
plot([0 simulink_time],[minx(6) minx(6)], 'b--','LineWidth',2)
hold on
plot([0 : Ts : simulink_time], x(6, :),'g','LineWidth',2)
axis([0 simulink_time minx(6) - 0.5 maxx(6) + 0.5])
hold on
