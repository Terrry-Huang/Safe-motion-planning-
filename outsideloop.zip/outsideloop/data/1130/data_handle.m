clc;clear all; close all;
load xo.mat
load uo.mat
load x.mat
load u.mat
Ts = 0.2;
T = 10;
ref = [];
for t = 0 : Ts : 10 * T
    ref = [ref; 5 * cos(0.2 * pi * t), 5 * sin(0.2 * pi * t), 3];
end

for k = 1 : 50
    xo(:, k + 50) = xo(:, k);
    uo(:, k + 50) = uo(:, k);
end
xo(:,101) = xo(:,1);

%% ��λ��ͼ
figure(1)
plot3(ref(:,1), ref(:,2), ref(:,3), 'r', 'LineWidth', 1)
hold on
plot3(xo(1, :), xo(2, :), xo(3, :), 'b', 'LineWidth', 1)
hold on
plot3(x(1, :), x(2, :), x(3, :), 'g', 'LineWidth', 1)
axis([-6 6 -6 6 0 4])
hold on

%% λ��Լ��
figure(2)
subplot(3, 1, 1)
plot( [0, 20],[8, 8], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), ref(1: 101, 1), 'r', 'LineWidth', 1)
hold on
plot( [0, 20],[-8, -8], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(1, :), 'b', 'LineWidth', 1)
hold on 
plot((0 : Ts : 2 * T), x(1, :), 'g', 'LineWidth', 1)
grid on
subplot(3, 1, 2)
plot((0 : Ts : 2 * T), ref(1: 101, 2), 'r', 'LineWidth', 1)
hold on
plot( [0, 20],[4, 4], 'r--', 'LineWidth', 1)
hold on
plot( [0, 20],[-4, -4], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(2, :), 'b', 'LineWidth', 1)
hold on 
plot((0 : Ts : 2 * T), x(2, :), 'g', 'LineWidth', 1)
axis([0 20 -5 5])
grid on
subplot(3, 1, 3)
plot((0 : Ts : 2 * T), ref(1: 101, 3), 'r', 'LineWidth', 1)
hold on
plot( [0, 20],[0, 0], 'r--', 'LineWidth', 1)
hold on
plot( [0, 20],[4, 4], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(3, :), 'b', 'LineWidth', 1)
hold on 
plot((0 : Ts : 2 * T), x(3, :), 'g', 'LineWidth', 1)
axis([0 20 0 4])
grid on



%% �ٶ�Լ��
figure(3)
subplot(3, 1, 1)
plot( [0, 20],[8, 8], 'r--', 'LineWidth', 1)
hold on
plot( [0, 20],[-8, -8], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(4, :), 'b', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), x(4, :), 'g', 'LineWidth', 1)
axis([0 20 -5 5])
grid on
subplot(3, 1, 2)
plot( [0, 20],[4, 4], 'r--', 'LineWidth', 1)
hold on
plot( [0, 20],[-4, -4], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(5, :), 'b', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), x(5, :), 'g', 'LineWidth', 1)
axis([0 20 -5 5])
grid on
subplot(3, 1, 3)
plot( [0, 20],[0, 0], 'r--', 'LineWidth', 1)
hold on
plot( [0, 20],[4, 4], 'r--', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), xo(6, :), 'b', 'LineWidth', 1)
hold on
plot((0 : Ts : 2 * T), x(6, :), 'g', 'LineWidth', 1)
axis([0 20 -5 5])
grid on

%% ״̬Լ��
figure(4)
plot( [0, 20],[15, 15], 'r--', 'LineWidth', 1)
hold on
plot((Ts : Ts : 2 * T), sqrt( uo(1, :).^2 + uo(2, :).^2 + ( uo(3, :) + 9.81 ).^2 ), 'b', 'LineWidth', 1 )
hold on
plot((Ts : Ts : 2 * T), sqrt( u(1, :).^2 + u(2, :).^2 + ( u(3, :) + 9.81 ).^2 ), 'g', 'LineWidth', 1 )
axis([0 20 0 16])
grid on