Taken from https://www.mathworks.com/matlabcentral/fileexchange/8396-draw-3d-arrows

Changshun Deng (2020). Draw 3D arrows (https://www.mathworks.com/matlabcentral/fileexchange/8396-draw-3d-arrows), MATLAB Central File Exchange. Retrieved May 12, 2020.
